#include <iostream>
using namespace std;

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char **argv)
{
	int num_read;
	char * buf;

	//Arg Count
	if (argc < 1) 
	{cout << "No Arguments" << endl;}

	//Open File	
	FILE * fp;
	fp = fopen(argv[1], "r");
	if(fp == NULL) {perror(argv[1]); exit(1); }

	//Determine File size
	fseek (fp, 0, SEEK_END);
	size_t fSize = ftell(fp);
	rewind(fp);

	//Set Buffer
	buf = (char*) malloc (sizeof(char)*fSize);
	if (buf == NULL) {fputs ("Memory error", stderr); exit(2);}

	//Read File (Set Buf)
	num_read = fread(buf, sizeof(char), fSize, fp);
	if (ferror(fp)) { perror("fread"); exit(1);}
	buf[num_read*sizeof(char)] = '\0';

	
	char * newWord_buf = buf;	
	//Count Words
	int word_c = 1;
	char * newWord = strtok (newWord_buf, " ");
	while (newWord != NULL) {
		++word_c;
		newWord = strtok (NULL, " ");
	}	

        char * newLine_buf = buf;
	//Count New Lines 
        int line_c;
        char * newLine = strtok (newLine_buf, "\n");    
        for (line_c = 1;newLine != NULL;line_c++) {
                newLine = strtok (NULL, "\n");  
        }
          
	//Printing 
	cout <<"\t"<<line_c<<"\t"<<word_c << "\t" << fSize<<" "<< argv[1] << endl;

	//Closing File
	if(fclose(fp) != 0) { perror(argv[1]); exit(1); }
	return 0;
}
